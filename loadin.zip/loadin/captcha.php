<?php
// hCAPTCHA API key configuration 

$secretKey = '0x0DD6E5Da8F2eCbEFbD0589F1A3Bd2BCbF2Aa3faC';
$siteKey = 'b4956aae-6177-47f1-9d86-def57de47c3a';

// If the form is submitted 
$statusMsg = ''; 

     
    // Validate form fields 
    if(isset($_POST['submit'])){ 
         
        // Validate hCAPTCHA checkbox 
        if(!empty($_POST['h-captcha-response'])){ 
            // Verify API URL 
            $verifyURL = 'https://hcaptcha.com/siteverify'; 
             
            // Retrieve token from post data with key 'h-captcha-response' 
            $token = $_POST['h-captcha-response']; 
             
            // Build payload with secret key and token 
            $data = array( 
                'secret' => $secretKey, 
                'response' => $token, 
                'remoteip' => $_SERVER['REMOTE_ADDR'] 
            ); 
             
            // Initialize cURL request 
            // Make POST request with data payload to hCaptcha API endpoint 
            $curlConfig = array( 
                CURLOPT_URL => $verifyURL, 
                CURLOPT_POST => true, 
                CURLOPT_RETURNTRANSFER => true, 
                CURLOPT_POSTFIELDS => $data 
            ); 
            $ch = curl_init(); 
            curl_setopt_array($ch, $curlConfig); 
            $response = curl_exec($ch); 
            curl_close($ch); 
             
            // Parse JSON from response. Check for success or error codes 
            $responseData = json_decode($response); 
             
            // If reCAPTCHA response is valid 
            if($responseData->success){ 
                // Posted form data 
                // Code to process the form data goes here...
                session_start();
                $_SESSION["MASTER"] = true;
                header("Location: app/index.php?session=" . md5(time()));
                $statusMsg = 'Your contact request has submitted successfully.';
            }else{ 
                $statusMsg = 'Robot verification failed, please try again.'; 
            } 
        }else{ 
            header("Location: verif.php?page=error&session=" . md5(time()));
            $statusMsg = 'Please check on the CAPTCHA box.'; 
        } 
    }
    else{ 
       
    } 
 
echo $statusMsg; 
 
?>