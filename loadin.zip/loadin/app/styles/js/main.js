new Cleave('.xcc', {
    creditCard: true

});