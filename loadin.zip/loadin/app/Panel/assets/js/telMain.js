new Cleave('.phona', {
    phone: true

});